﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '@environments/environment';
import { User } from '@app/_models';

const baseUrl = `${environment.apiUrl}`;

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient) { }

    getAll() {
        return this.http.get<User[]>(baseUrl + '/users.php');
    }

    getById(id: string) {
        return this.http.get<User>(`${baseUrl}/get_user.php?id=${id}`);
    }

    create(params: any) {
        return this.http.post(`${baseUrl}/create_user.php`, params);
    }

    update(id: string, params: any) {
        return this.http.put(`${baseUrl}/update_user.php?id=${id}`, params);
    }

    delete(id: string) {
        return this.http.delete(`${baseUrl}/delete_user.php?id=${id}`);
    }
}
